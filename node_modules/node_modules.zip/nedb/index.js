var Datastore = require('./lib/datastore');

module.exports = Datastore;
